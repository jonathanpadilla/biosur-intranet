<?php

namespace PluginBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PluginBundle extends Bundle
{
}
