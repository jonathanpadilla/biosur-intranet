<?php

namespace ClienteBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ClienteBundle extends Bundle
{
}
