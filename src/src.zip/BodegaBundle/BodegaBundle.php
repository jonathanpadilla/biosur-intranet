<?php

namespace BodegaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BodegaBundle extends Bundle
{
}
