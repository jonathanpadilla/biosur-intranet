<?php

namespace BaseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BaseBundle extends Bundle
{
}
