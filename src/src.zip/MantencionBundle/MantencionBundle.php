<?php

namespace MantencionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MantencionBundle extends Bundle
{
}
