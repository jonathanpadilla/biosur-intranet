<?php

namespace VentaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class VentaBundle extends Bundle
{
}
