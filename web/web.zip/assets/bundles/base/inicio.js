$(function(){
	demoHighCharts.init();
});